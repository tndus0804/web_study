package net.datasa.test.repository;

import net.datasa.test.domain.entity.ReplyEntity;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 리플 관련 repository
 */

//@Repository
//public interface ReplyRepository extends JpaRepository<ReplyEntity, Integer> {
//
//
//}
